package heranca;

public class FuncionarioComissionado {

		protected String nome;
		private String cpf;
		protected double percentualSobVendas;
		protected double totalVendas;
		protected double salario;
		
		public String getNome() {
			return nome;
		}
		public void setNome(String nome) {
			this.nome = nome;
		}
		public String getCpf() {
			return cpf;
		}
		public void setCpf(String cpf) {
			this.cpf = cpf;
		}
		public double getPercentualSobVendas() {
			return percentualSobVendas;
		}
		public void setPercentualSobVendas(double percentualSobVendas) {
			this.percentualSobVendas = percentualSobVendas;
		}
		public double getTotalVendas() {
			return totalVendas;
		}
		public void setTotalVendas(double totalVendas) {
			this.totalVendas = totalVendas;
		}

		
		public FuncionarioComissionado(String nome, String cpf, double percentualSobVendas, double totalVendas) {
			
			this.nome = nome;
			this.cpf = cpf;
			this.percentualSobVendas = percentualSobVendas;
			this.totalVendas = totalVendas;
		}
		
		public double getSalario () {
			salario = (totalVendas * percentualSobVendas)/ 100;
			System.out.println("Cálculo do funcionário: " + nome);
			System.out.println("O salário calculado é igual a: " + salario);
			return salario;
		}
		
}
