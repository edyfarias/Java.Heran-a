package heranca;

public class Principal {

	public static void main(String[] args) {
		
		FuncionarioComissionado funcionario1 = new FuncionarioComissionado("João", "152.158.654-95", 10, 50000.00);
		funcionario1.getSalario();
		
		FuncionarioComissionadoBase funcionario2 = new FuncionarioComissionadoBase("Lucas", "126.158.456-55", 10, 50000.00, 1500.00);
		funcionario2.getSalario();
	}

}
